﻿namespace PVolume
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimp = new System.Windows.Forms.Button();
            this.lblRai = new System.Windows.Forms.Label();
            this.lblAlt = new System.Windows.Forms.Label();
            this.lblVol = new System.Windows.Forms.Label();
            this.txtRai = new System.Windows.Forms.TextBox();
            this.txtAlt = new System.Windows.Forms.TextBox();
            this.txtVol = new System.Windows.Forms.TextBox();
            this.btnFchar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.Lime;
            this.btnCalc.Location = new System.Drawing.Point(52, 187);
            this.btnCalc.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(138, 50);
            this.btnCalc.TabIndex = 0;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimp
            // 
            this.btnLimp.Location = new System.Drawing.Point(202, 187);
            this.btnLimp.Margin = new System.Windows.Forms.Padding(6);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(138, 50);
            this.btnLimp.TabIndex = 1;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = true;
            this.btnLimp.Click += new System.EventHandler(this.btnLimp_Click);
            // 
            // lblRai
            // 
            this.lblRai.AutoSize = true;
            this.lblRai.Location = new System.Drawing.Point(19, 17);
            this.lblRai.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRai.Name = "lblRai";
            this.lblRai.Size = new System.Drawing.Size(48, 24);
            this.lblRai.TabIndex = 2;
            this.lblRai.Text = "Raio";
            // 
            // lblAlt
            // 
            this.lblAlt.AutoSize = true;
            this.lblAlt.Location = new System.Drawing.Point(19, 76);
            this.lblAlt.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAlt.Name = "lblAlt";
            this.lblAlt.Size = new System.Drawing.Size(58, 24);
            this.lblAlt.TabIndex = 3;
            this.lblAlt.Text = "Altura";
            // 
            // lblVol
            // 
            this.lblVol.AutoSize = true;
            this.lblVol.Location = new System.Drawing.Point(19, 135);
            this.lblVol.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblVol.Name = "lblVol";
            this.lblVol.Size = new System.Drawing.Size(76, 24);
            this.lblVol.TabIndex = 4;
            this.lblVol.Text = "Volume";
            // 
            // txtRai
            // 
            this.txtRai.Location = new System.Drawing.Point(124, 12);
            this.txtRai.Margin = new System.Windows.Forms.Padding(6);
            this.txtRai.Name = "txtRai";
            this.txtRai.Size = new System.Drawing.Size(387, 29);
            this.txtRai.TabIndex = 5;
            this.txtRai.Validating += new System.ComponentModel.CancelEventHandler(this.txtRai_Validating);
            // 
            // txtAlt
            // 
            this.txtAlt.Location = new System.Drawing.Point(124, 71);
            this.txtAlt.Margin = new System.Windows.Forms.Padding(6);
            this.txtAlt.Name = "txtAlt";
            this.txtAlt.Size = new System.Drawing.Size(387, 29);
            this.txtAlt.TabIndex = 6;
            this.txtAlt.Validating += new System.ComponentModel.CancelEventHandler(this.txtAlt_Validating);
            // 
            // txtVol
            // 
            this.txtVol.Enabled = false;
            this.txtVol.Location = new System.Drawing.Point(124, 130);
            this.txtVol.Margin = new System.Windows.Forms.Padding(6);
            this.txtVol.Name = "txtVol";
            this.txtVol.ReadOnly = true;
            this.txtVol.Size = new System.Drawing.Size(387, 29);
            this.txtVol.TabIndex = 7;
            // 
            // btnFchar
            // 
            this.btnFchar.BackColor = System.Drawing.Color.Red;
            this.btnFchar.Location = new System.Drawing.Point(352, 187);
            this.btnFchar.Margin = new System.Windows.Forms.Padding(6);
            this.btnFchar.Name = "btnFchar";
            this.btnFchar.Size = new System.Drawing.Size(138, 50);
            this.btnFchar.TabIndex = 8;
            this.btnFchar.Text = "Fechar";
            this.btnFchar.UseVisualStyleBackColor = false;
            this.btnFchar.Click += new System.EventHandler(this.btnFchar_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 252);
            this.Controls.Add(this.btnFchar);
            this.Controls.Add(this.txtVol);
            this.Controls.Add(this.txtAlt);
            this.Controls.Add(this.lblVol);
            this.Controls.Add(this.lblAlt);
            this.Controls.Add(this.lblRai);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtRai);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmPrincipal";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimp;
        private System.Windows.Forms.Label lblRai;
        private System.Windows.Forms.Label lblAlt;
        private System.Windows.Forms.Label lblVol;
        private System.Windows.Forms.TextBox txtRai;
        private System.Windows.Forms.TextBox txtAlt;
        private System.Windows.Forms.TextBox txtVol;
        private System.Windows.Forms.Button btnFchar;
    }
}

