﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class frmPrincipal : Form
    {
        public double rai;
        public double alt;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {


            if ((!double.TryParse(txtRai.Text, out rai)) || (!double.TryParse(txtAlt.Text, out alt)))
            {
                MessageBox.Show("Os Valores devem ser decimais");
                txtRai.Focus();
            }
            else if (rai <= 0 || alt <= 0)
            {
                MessageBox.Show("Valores devem ser maiores que zero.");
                txtRai.Focus();
            }
            else
            {
                double vol;
                vol = Math.PI * Math.Pow(rai, 2) * alt;

                txtVol.Text = vol.ToString("N2");
            }

        }

        private void btnLimp_Click(object sender, EventArgs e)
        {

            txtVol.Text = "";
            txtRai.Text = "";
            txtAlt.Text = "";

        }

        private void btnFchar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRai_Validating(object sender, CancelEventArgs e)
        {
            double valor;
            if (!double.TryParse(txtRai.Text, out rai))
            {
                MessageBox.Show("Valor de Raio deve ser decimal");
                txtRai.Focus();
            }
            else if (rai <= 0)
            {
                MessageBox.Show("Valor de Raio deve ser maior que zero.");
                txtRai.Focus();
            }
        }

        private void txtAlt_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtAlt.Text, out alt))
            {
                MessageBox.Show("Valor de Altura deve ser decimal");
                txtAlt.Focus();
            }
            else if (alt <= 0)
            {
                MessageBox.Show("Valor de Altura deve ser maior que zero.");
                txtAlt.Focus();
            }
        }
    }
}
