﻿namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblNumUm = new System.Windows.Forms.Label();
            this.txtNumUm = new System.Windows.Forms.TextBox();
            this.txtNumDois = new System.Windows.Forms.TextBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.lblNumDois = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnMais = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.btnMultip = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(328, 24);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 34);
            this.btnLimpar.TabIndex = 0;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblNumUm
            // 
            this.lblNumUm.AutoSize = true;
            this.lblNumUm.Location = new System.Drawing.Point(33, 24);
            this.lblNumUm.Name = "lblNumUm";
            this.lblNumUm.Size = new System.Drawing.Size(53, 13);
            this.lblNumUm.TabIndex = 1;
            this.lblNumUm.Text = "Número 1";
            // 
            // txtNumUm
            // 
            this.txtNumUm.Location = new System.Drawing.Point(94, 21);
            this.txtNumUm.Name = "txtNumUm";
            this.txtNumUm.Size = new System.Drawing.Size(215, 20);
            this.txtNumUm.TabIndex = 2;
            this.txtNumUm.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumUm_Validating);
            // 
            // txtNumDois
            // 
            this.txtNumDois.Location = new System.Drawing.Point(94, 47);
            this.txtNumDois.Name = "txtNumDois";
            this.txtNumDois.Size = new System.Drawing.Size(215, 20);
            this.txtNumDois.TabIndex = 3;
            this.txtNumDois.Validating += new System.ComponentModel.CancelEventHandler(this.txtNumDois_Validating);
            // 
            // txtResult
            // 
            this.txtResult.Enabled = false;
            this.txtResult.Location = new System.Drawing.Point(94, 73);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(215, 20);
            this.txtResult.TabIndex = 4;
            // 
            // lblNumDois
            // 
            this.lblNumDois.AutoSize = true;
            this.lblNumDois.Location = new System.Drawing.Point(33, 50);
            this.lblNumDois.Name = "lblNumDois";
            this.lblNumDois.Size = new System.Drawing.Size(53, 13);
            this.lblNumDois.TabIndex = 5;
            this.lblNumDois.Text = "Número 2";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(33, 76);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(55, 13);
            this.lblResult.TabIndex = 6;
            this.lblResult.Text = "Resultado";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(328, 65);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 34);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnMais
            // 
            this.btnMais.Location = new System.Drawing.Point(50, 113);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(75, 68);
            this.btnMais.TabIndex = 8;
            this.btnMais.Text = "+";
            this.btnMais.UseVisualStyleBackColor = true;
            this.btnMais.Click += new System.EventHandler(this.btnMais_Click);
            // 
            // btnMenos
            // 
            this.btnMenos.Location = new System.Drawing.Point(131, 113);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(75, 68);
            this.btnMenos.TabIndex = 9;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = true;
            this.btnMenos.Click += new System.EventHandler(this.btnMenos_Click);
            // 
            // btnMultip
            // 
            this.btnMultip.Location = new System.Drawing.Point(212, 113);
            this.btnMultip.Name = "btnMultip";
            this.btnMultip.Size = new System.Drawing.Size(75, 68);
            this.btnMultip.TabIndex = 10;
            this.btnMultip.Text = "x";
            this.btnMultip.UseVisualStyleBackColor = true;
            this.btnMultip.Click += new System.EventHandler(this.btnMultip_Click);
            // 
            // btnDiv
            // 
            this.btnDiv.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDiv.Location = new System.Drawing.Point(293, 113);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(75, 68);
            this.btnDiv.TabIndex = 11;
            this.btnDiv.Text = "/";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 193);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btnMultip);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblNumDois);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtNumDois);
            this.Controls.Add(this.txtNumUm);
            this.Controls.Add(this.lblNumUm);
            this.Controls.Add(this.btnLimpar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblNumUm;
        private System.Windows.Forms.TextBox txtNumUm;
        private System.Windows.Forms.TextBox txtNumDois;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label lblNumDois;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button btnMultip;
        private System.Windows.Forms.Button btnDiv;
    }
}

