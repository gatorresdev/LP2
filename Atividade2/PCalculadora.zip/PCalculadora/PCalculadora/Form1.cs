﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        public double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
           
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumUm.Clear();
            txtNumDois.Clear();
            txtResult.Clear();    
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResult.Text = resultado.ToString();
        }

        private void btnMultip_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResult.Text = resultado.ToString();
        }

        private void txtNumUm_Validating(object sender, CancelEventArgs e)
        {
            if (Double.TryParse(txtNumUm.Text, out numero1))
            {
                return;
            }
            else
            {
                MessageBox.Show("Valor Inválido");
            }
        }

        private void txtNumDois_Validating(object sender, CancelEventArgs e)
        {
            if (Double.TryParse(txtNumDois.Text, out numero2))
            {
                return;
            }
            else
            {
                MessageBox.Show("Valor Inválido");
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("O número 2 precisa ser diferente de Zero!");
                txtNumDois.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResult.Text = resultado.ToString();
            }
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResult.Text = resultado.ToString();
        }

    }
}
