﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        public double imc, peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Double.TryParse(mskbxPeso.Text, out peso);
            Double.TryParse(mskbxAlt.Text, out altura);

            imc = peso/Math.Pow(altura, 2);
            imc = Math.Round(imc,2);

            if(imc < 18.5) {
                MessageBox.Show("IMC = "+imc.ToString()+" - Magreza");
            }else if (imc < 24.9)
            {
                MessageBox.Show("IMC = "+imc.ToString()+" - Normal");
            }
            else if (imc < 29.9)
            {
                MessageBox.Show("IMC = "+imc.ToString()+" - Sobrepeso");
            }
            else if (imc < 39.9)
            {
                MessageBox.Show("IMC = "+imc.ToString()+" - Obesidade");
            }
            else
            {
                MessageBox.Show("IMC = "+imc.ToString()+" - Obesidade Grave");
            }
        }
    }
}
